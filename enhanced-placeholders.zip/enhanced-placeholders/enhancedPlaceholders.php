<?php
/*
	Plugin Name: Enhanced Placeholders
	Plugin URI:  http://www.sitewidgets.com/plugins/phplist/enhanced_placeholders/
	Description: Extends phpList placeholders to include some additional ones and the ability to add many more.
	Version: 0.98
	Author: M.D. Green
	Author URI: http://saesolved.com/
	Copyright (C) 2010-2011 by SaeSolved::(TM) LLC

	This program is free software: you can redistribute it and/or modify it under the terms of the
	GNU General Public License (http://www.gnu.org/licenses/) as published by the Free Software Foundation,
	either version 3 of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
	implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

	The author of this plugin wishes to express appreciation for the posting of "Live tags hack" at
	http://forums.phplist.com/viewtopic.php?f=7&t=8283&p=27789&hilit=live+tags+processing#p27789,
	which served as the seed from which this plugin grew.

	In addition, the author is very grateful to all of those who have given feedback at http://forums.phplist.com/viewtopic.php?f=7&t=33957 --
	especially those of duncanc, culminating in his posting of revised code at 1:50pm, 16 June 2011. The revisions in that posting have been
	completely incorporated into this version of this plugin.

	The convention of using "{" and "}" -- rather than "[" and "]" -- for placeholder delimiters has been used here. This is used by both "Live tags hack" and the PEAR template system library (HTML/Template/PHPLIB.php). This allows "[" and "]" to be used for constructs in emails other than placeholders without creating possible conflicts.

	This is set up so that placeholders of the form {PLACEHOLDER} can be used instead of those of the form [PLACEHOLDER] for many instances of the latter.

	When this plugin is used, in order to process queues using cron jobs one must use something similar to "What finally worked for me was to set up a curl call in a php script as follows:" at http://docs.phplist.com/CronJobExamples. Other approaches seem not to properly initialize the plugin.
*/

class enhancedPlaceholders extends phplistPlugin {
	public $name		= "Enhanced Placeholders";
	public $coderoot	= '';

	function __construct() {
		$this->coderoot = dirname(__FILE__).'/enhanced_placeholders/';
		parent::__construct();
	}

	public function adminmenu() {
		return array(
			"main" => "Enhanced Placeholders"
		);
	}
}

?>
