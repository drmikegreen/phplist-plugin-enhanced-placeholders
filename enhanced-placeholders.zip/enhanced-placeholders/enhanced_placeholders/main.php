<?php
	include_once('enhancedPlaceholdersAdmin.php');
	$ep_admin = new enhancedPlaceholdersAdmin();
?>
<h2>Enhanced Placeholders</h2>

Enhanced Placeholders use the convention of "{" and "}" -- rather than "[" and "]" -- for placeholder delimiters. This allows "[" and "]" to be used for constructs in emails other than placeholders without creating possible conflicts.
<br /><br />
These placeholders can be used in the subject line as well as the content of HTML and text messages. They can also be nested -- i.e., a placeholder can be used as part of a different placeholder.
<br /><br />
Placeholders of the form {PLACEHOLDER} can be used instead of those of the form [PLACEHOLDER] for many instances of the latter.
<br /><br />
You can also create placeholders of a number of different types using the "add a new placeholder" link below. Any of the placeholders that you add can then be edited or deleted/removed using this page. Note that the code will not allow you (if you have JavaScript turned on) to add duplicates of placeholders that you have already created or of <?php echo $ep_admin->listPreExistingPlaceholders(); ?>.
<br /><br />
If the type of the placeholder is "HTML," a field is available for entering what should be used in the text portion of an email or in the subject line.
<br /><br />
There are five "hard-wired" enhanced placeholders:
<ul>
<li>{EMAIL}: the email address of the person to whom an email is sent.</li>
<li>{LIST_UNSUBSCRIBEURL}: a link containing a query string of the form &quot;p=unsubscribe&amp;uid=&lt;unique id for the user&gt;&amp;listid=&lt;list id number&gt;&quot;, which can be used to access a page for unsubscribing from a specific list generated using the <a href="http://sitewidgets.com/plugins/phplist/unsubscribe_page/" target="_blank">Unsubscribe Page plugin</a>.</li>
<li>{MID}: the message id.</li>
<li>{UID}: the unique id of the person to whom the email is sent.</li>
<li>{VIA_LIST_NAMES}: the names of the lists via which a specific message is sent. The names of the lists are separated by a dash (-).</li>
</ul>
<?php
	include('additional_instructions.php');
?>
In order to process queues using cron jobs when these enhanced placeholders are used, one must use something similar to "...set up a curl call in a php script..." at http://docs.phplist.com/CronJobExamples. Other approaches seem not to properly initialize the plugin used to create these placeholders.
<br />
<?php
	if (isset($_REQUEST["submit"]) && 'Save' == $_REQUEST["submit"]) {
		$ep_admin->updatePlaceholder($_REQUEST["id"]);
	} elseif (isset($_REQUEST["id"]) && $_REQUEST["id"]) {
		if (isset($_REQUEST["actn"]) && 'remove' == $_REQUEST["actn"]) {
			$ep_admin->removePlaceholder($_REQUEST["id"]);
		} else {
			echo '<form method="post">';
			$ep_admin->showPlaceholderEditForm($_REQUEST["id"]);
			echo '<input type="submit" name="submit" id="submit" value="Save" />';
			echo '</form>';
			return;
		}
	}
	$ep_admin->showEnhancedPlaceholders();
?>


