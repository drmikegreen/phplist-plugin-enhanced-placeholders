<?php
/*
	Class Name: enhancedPlaceholdersAdmin
	Plugin URI: http://www.sitewidgets.com/plugins/phplist/enhanced_placeholders/
	Description: Extends enhancedPlaceholdersPopulate to provide the administrative function of being able to create and edit new placeholders.
	Version: 0.97
	Author: M.D. Green
	Author URI: http://saesolved.com/
*/

include_once('enhancedPlaceholdersPopulate.php');

class enhancedPlaceholdersAdmin extends enhancedPlaceholdersPopulate {

	protected $add_new_placeholder	= 'add_new_placeholder';

	public function __construct () {
		unset($this->enhanced_placeholders);
		$this->retrievePlaceholderArray();
	}

	public function listPreExistingPlaceholders () {
		$placeholder_ids     = array_merge($this->hardwired_placeholders, $this->dynamic_config_placeholders);
		sort($placeholder_ids);
		$nr_placeholder_ids  = count($placeholder_ids);
		$placeholder_id_list = '';
		$nr                  = 0;
		foreach ($placeholder_ids as $id4list) {
			if ($placeholder_id_list) {
				$placeholder_id_list .= ', ';
			}
			if (++$nr == $nr_placeholder_ids) {
				$placeholder_id_list .= 'or ';
			}
			$placeholder_id_list .= "$id4list";
		}
		return $placeholder_id_list;
	}

	public function removePlaceholder ($id = '') {
		$id = $this->placeholder_delimiters[0].$id.$this->placeholder_delimiters[1];
		unset($this->enhanced_placeholders[$id]);
		$this->storePlaceholderArray();
		Redirect("main&pi=enhancedPlaceholders");
	}

	public function showEnhancedPlaceholders () {
		echo '<hr/>';
		echo '<table style="width: 100%;">';
		if (is_array($this->enhanced_placeholders) && count($this->enhanced_placeholders)) {
			ksort($this->enhanced_placeholders);
			foreach ($this->enhanced_placeholders as $placeholder => $props) {
				echo '<tr>';
				echo '<td style="padding-right: 15px;"><a href="'.PageURL2('main&pi=enhancedPlaceholders&id='.str_replace($this->placeholder_delimiters, '', $placeholder).'&actn=edit').'">edit</a></td>';
				echo '<td style="text-align: right;">Placeholder:</td><td style="font-weight: bold;">'.$placeholder.'</td><td style="text-align: right;">Type:</td><td>'.$props['type'].'</td>';
				echo '</tr><tr>';
				echo '<td style="padding-right: 15px;"><a href="'.PageURL2('main&pi=enhancedPlaceholders&id='.str_replace($this->placeholder_delimiters, '', $placeholder).'&actn=remove').'" onclick="return confirm(\'Are you certain you wish to remove '.$placeholder.'? If not, click Cancel. If so, click OK.\')">remove</a></td>';
				echo '<td style="text-align: right;">Description:</td><td colspan="3">'.$props['description'].'</td>';
				echo '</tr><tr>';
				echo '<td colspan="2" style="text-align: right; vertical-align: top;">Value:</td><td colspan="3">'.$props['value'].'</td>';
				echo '</tr>';
				if (isset($props['value_text'])) {
					echo '<tr>';
					echo '<td colspan="2" style="text-align: right; vertical-align: top;">Text value:</td><td colspan="3">'.nl2br($props['value_text']).'</td>';
					echo '</tr>';
				}
				echo '<tr>';
				echo '<td colspan="5"><hr/></td>';
				echo '</tr>';
			}
		}
		echo '</table>';
		echo '<p><a href="'.PageURL2('main&pi=enhancedPlaceholders&id='.$this->add_new_placeholder).'">add a new placeholder</a><br /><br /><hr/></p>';
	}

	public function showPlaceholderEditForm ($id = '') {
		$value_text_field_set = false;
		if ($id == $this->add_new_placeholder) {
			$placeholder_ids     = array_merge(array_keys($this->enhanced_placeholders), $this->hardwired_placeholders, $this->dynamic_config_placeholders);
			$placeholder_id_list = '"' . implode('", "', $placeholder_ids) . '"';
			echo "
				<script type='text/javascript'>
					var placeholder_array = new Array($placeholder_id_list);
					function isPlaceHolderUnique (placeholder) {
						var placeholderUC = placeholder.value.toUpperCase();
						for (var i = 0; i < placeholder_array.length; i++) {
							if (placeholder_array[i] == '{$this->placeholder_delimiters[0]}' + placeholderUC + '{$this->placeholder_delimiters[1]}') {
								alert(placeholder_array[i] + ' is already in use.');
								placeholder.value = '';
								return false;
							}
						}
						placeholder.value = placeholderUC;
						return true;
					}
				</script>";
		}
		echo '<table style="width: 100%;">';
		echo '<tr><td style="vertical-align: top;">';
		if ($id == $this->add_new_placeholder) {
			echo '<b>Adding:</b></td><td>{<input name="id" id="id" type="text" value="" onchange="{isPlaceHolderUnique(this)?true:focus(this); return false;}" />}<br />';
			$this->enhanced_placeholders[$id] = $this->enhanced_placeholder_structure;
		} else {
			echo "<input name=\"id\" id=\"id\" type=\"hidden\" value=\"$id\" /><br />";
			$id = $this->placeholder_delimiters[0].$id.$this->placeholder_delimiters[1];
			echo "<b>Editing:</b></td><td style=\"vertical-align: bottom;\"><b>$id</b><br />";
		}
		echo '</td></tr>';
		foreach ($this->enhanced_placeholders[$id] as $key => $value) {
			if ('type' == $key) {
				echo "<tr id=\"id_$key\" name=\"id_$key\"><td style=\"vertical-align: top;\">$key:</td><td><select name=\"$key\" id=\"$key\" onchange=\"this.options[this.selectedIndex].value=='html'?document.getElementById('id_value_text').style.display='table-row':document.getElementById('id_value_text').style.display='none'\">";
				foreach ($this->permitted_types as $tp) {
					if ($tp == $value) {
						$selected = ' selected="selected"';
					} else {
						$selected = '';
					}
					echo "<option value=\"$tp\"$selected>$tp</option>";
				}
				echo '</select>';
			} elseif ('value' == $key) {
				echo "<tr id=\"id_$key\" name=\"id_$key\"><td style=\"vertical-align: top;\">$key:</td><td><textarea name=\"$key\" id=\"$key\" cols=\"60\" rows=\"7\">$value</textarea>";
			} elseif ('value_text' == $key) {
				echo "<tr id=\"id_$key\" name=\"id_$key\" style=\"display: table-row;\"><td style=\"vertical-align: top;\">text value:</td><td><textarea name=\"$key\" id=\"$key\" cols=\"60\" rows=\"5\">$value</textarea>";
				$value_text_field_set = true;
			} elseif ('nested_placeholders' != $key) {
				echo "<tr id=\"id_$key\" name=\"id_$key\"><td style=\"vertical-align: top;\">$key:</td><td><input name=\"$key\" id=\"$key\" type=\"text\" value=\"$value\" />";
			}
			echo '</td></tr>';
		}
		if (!$value_text_field_set) {
			echo "<tr id=\"id_value_text\" name=\"id_value_text\" style=\"display: none;\"><td style=\"vertical-align: top;\">text value:</td><td><textarea name=\"value_text\" id=\"value_text\" cols=\"60\" rows=\"5\"></textarea></td></tr>";
		}
		echo '</table>';
	}

	public function verifyPlaceholderUnique ($id = '') {
		if (in_array($id, array_keys($this->enhanced_placeholders))) {
		} else {
			return true;
		}
	}

	public function updatePlaceholder ($id = '') {
		$id						= $this->placeholder_delimiters[0].strtoupper($id).$this->placeholder_delimiters[1];
		$nested_placeholders	= array();
		$placeholders_found		= array();
		$type					= stripslashes($_POST['type']);
		$value					= stripslashes($_POST['value']);
		if ('html' == $type) {
			if (isset($_POST['value_text'])) {
				$value_text = stripslashes($_POST['value_text']);
			} else {
				$value_text = strip_tags($value);
			}
		} elseif (isset($value_text)) {
			unset($value_text);
		}
		// Find any nested placeholders
		preg_match_all($this->placeholder_regex, $value, $placeholders_found);
		foreach ($placeholders_found[0] as $placeholder) {
			$config_value = getConfig(strtolower(str_replace($this->placeholder_delimiters, '', $placeholder)));
			// create list of placeholder types nested in this placeholder
			if (isset($config_value) && $config_value != '') {
				$nested_placeholders[] = 'configuration_placeholders';
			} elseif (in_array($placeholder, array_keys($this->enhanced_placeholders))) {
				$nested_placeholders[] = 'enhanced_placeholders';
			} elseif (in_array($placeholder, $this->hardwired_placeholders)) {
				$nested_placeholders[] = 'hardwired_placeholders';
			} elseif (in_array($placeholder, array_keys($this->user_attribute_placeholders))) {
				$nested_placeholders[] = 'user_attribute_placeholders';
			}
		}
		$nested_placeholders = array_unique($nested_placeholders);
		$this->enhanced_placeholders[$id] = array(	'description'			=> stripslashes($_POST['description']),
													'nested_placeholders'	=> $nested_placeholders,
													'type'					=> $type,
													'value'					=> $value,
												 );
		if (isset($value_text)) {
			$this->enhanced_placeholders[$id]['value_text'] = $value_text;
		}
		$this->storePlaceholderArray();
		Redirect("main&pi=enhancedPlaceholders");
	}

}
?>