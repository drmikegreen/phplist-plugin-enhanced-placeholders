<?php
/*
	Plugin Name: Enhanced Placeholders
	Plugin URI:  http://www.sitewidgets.com/plugins/phplist/enhanced_placeholders/
	Description: Extends phpList placeholders to include some additional ones and the ability to add many more.
	Version: 0.98
	Author: M.D. Green
	Author URI: http://saesolved.com/
*/

class enhancedPlaceholdersPopulate  {

	protected $apply_template_to_text_messages	= true;
	protected $config_table_item				= 'enhanced_placeholders';
	protected $dynamic_config_placeholders		= array('{BLACKLIST}', '{BLACKLISTURL}', '{FORWARD}', '{FORWARDFORM}', '{FORWARDURL}', '{PREFERENCESURL}', '{PREFERENCES}', '{UNSUBSCRIBE}', '{UNSUBSCRIBEURL}',); // configuration parameter placeholders which are changed during mailings
	protected $enhanced_placeholder_structure	= array('description' => '', 'nested_placeholders' => array(), 'type' => '', 'value' => '', 'value_text' => '',);
	protected $enhanced_placeholders			= array();
	protected $hardwired_placeholders			= array('{EMAIL}', '{MID}', '{UID}', '{VIA_LIST_NAMES}', '{LIST_UNSUBSCRIBEURL}',);
	protected $legacy_placeholders_html			= array();
	protected $legacy_placeholders_text			= array();
	protected $list_names						= array();
	protected $list_names_separator				= ' - ';
	protected $max_recursions					= 9;
	protected $messageid						= 0;
	protected $mystery_word						= "abracadabra";
	protected $nested_placeholders				= array();
	protected $permitted_types					= array('html', 'PHP:date', 'PHP:eval', 'text',);
	protected $placeholder_delimiters			= array('{', '}'); // This must be consistent with $placeholder_regex
	protected $placeholder_regex				= "/\{[^}]+\}/"; // Thise must be consistent with $placeholder_delimiters
	protected $placeholders_list_html			= array();
	protected $placeholders_list_text			= array();
	protected $recursion_counter				= 0;
	protected $sent_via_listids					= array();
	protected $user_attribute_placeholders		= array();

	// Hold an instance of the class
	private static $instance;

	// The singleton method (http://php.net/manual/en/language.oop5.patterns.php)
	public static function instance() {
		if (!isset(self::$instance)) {
			$c = __CLASS__;
			self::$instance = new $c;
		}
		return self::$instance;
	}

	protected function __construct () {
		$this->getListNames();
		$this->getUserAttributePlaceholders();
		$this->getEnhancedPlaceholders(true);
	}

	public function processEnhancedPlaceholders ($messageid, $userdata, $user_att_values, $html, $text, $template, &$htmlmessage, &$textmessage, &$subject) {
		if ($this->messageid != $messageid) {
			$this->messageid  = $messageid;
		}
		if (is_array($html)) {
			foreach ($html as $key => $value) {
				$key = $this->placeholder_delimiters[0].strtoupper($key).$this->placeholder_delimiters[1];
				$this->legacy_placeholders_html[$key] = $value;
			}
		}
		if (is_array($text)) {
			foreach ($text as $key => $value) {
				$key = $this->placeholder_delimiters[0].strtoupper($key).$this->placeholder_delimiters[1];
				$this->legacy_placeholders_text[$key] = $value;
			}
		}
		if ($this->apply_template_to_text_messages && $template) {
			// Apply template to text message. (It has already been applied to the HTML message in sendemaillib.php.)
			$textmessage = str_replace("[CONTENT]", $textmessage, stripHTML($template));
		}
		if (!count($this->user_attribute_placeholders)) {
			$this->getUserAttributePlaceholders();
		}
		$this->getEnhancedPlaceholders();
		$this->putValuesInNestedPlaceholders($userdata, $user_att_values);
		$this->getPlaceholderLists($htmlmessage, $textmessage, $subject);
		$this->putValuesInPlaceholders($this->placeholders_list_html, $htmlmessage, $userdata, $user_att_values, false, true);
		$this->putValuesInPlaceholders($this->placeholders_list_text, $textmessage, $userdata, $user_att_values);
		$this->putValuesInPlaceholders($this->placeholders_list_subject, $subject,  $userdata, $user_att_values);
	}

	protected function getConfigurationPlaceholderValue ($placeholder, $return_for_not_set = '') {
		$ret = getConfig(strtolower(str_replace($this->placeholder_delimiters, '', $placeholder)));
		if (!isset($ret)) {
			$ret = $return_for_not_set;
		} elseif (false === $ret) {
			$ret = 'False';
		} elseif (true === $ret) {
			$ret = 'True';
		} elseif (!$ret) {
			$ret = '';
		}
		return $ret;
	}

	protected function getEnhancedPlaceholders ($is_construct = false) {
		$this->retrievePlaceholderArray();
		foreach ($this->enhanced_placeholders as $placeholder => $props) {
			$this->recursion_counter = 0;
			if (isset($props['nested_placeholders']) && count($props['nested_placeholders'])) {
				$this->getNestedEnhancedPlaceholders($placeholder, $props, $is_construct);
				$this->nested_placeholders[] = $placeholder;
			}
		}
	}

	protected function getListNames () {
		global $tables;
		$req = Sql_Query(sprintf('SELECT id, name FROM %s', $tables['list']));
		while ($row = Sql_Fetch_Row($req)) {
			$this->list_names[$row[0]] = stripslashes($row[1]);
		}
	}

	protected function getNestedEnhancedPlaceholders ($placeholder, &$props, $is_construct = false) {
		// Replace nested placeholders recursively. Only the extra placeholders added by this plugin are potentially nested beyond one level.
		$enhanced_placeholders	 = array_keys($this->enhanced_placeholders);
		$placeholders_found		 = array();
		preg_match_all($this->placeholder_regex, $props['value'], $placeholders_found);
		$placeholders_found		 = $placeholders_found[0];
		$placeholders_found_text = array();
		if (isset($props['value_text'])) {
			preg_match_all($this->placeholder_regex, $props['value_text'], $placeholders_found_text);
			$placeholders_found = array_unique(array_merge($placeholders_found, $placeholders_found_text[0]));
		}
		if (count($placeholders_found)) {
			$search_for   = array();
			$replace_with = array();
			foreach ($placeholders_found as $nested_placeholder) {
				if (in_array($nested_placeholder, $enhanced_placeholders)
						&& ('html' == $this->enhanced_placeholders[$nested_placeholder]['type']
							|| 'text' == $this->enhanced_placeholders[$nested_placeholder]['type'])) {
					$search_for[]   = $nested_placeholder;
					$replace_with[] = $this->enhanced_placeholders[$nested_placeholder]['value'];
				} elseif (!in_array($nested_placeholder, $this->dynamic_config_placeholders)) {
					// Configuration values can also be inserted at this point since they do not change during the sending of an email.
					$configuration_value = $this->getConfigurationPlaceholderValue($nested_placeholder, NULL);
					if (NULL != $configuration_value) {
						$search_for[]   = $nested_placeholder;
						$replace_with[] = $configuration_value;
					}
				}
			}
			$this->enhanced_placeholders[$placeholder]['value'] = str_replace($search_for, $replace_with, $this->enhanced_placeholders[$placeholder]['value']);
			if (isset($placeholders_found_text[0]) && count($placeholders_found_text[0])) {
				$this->enhanced_placeholders[$placeholder]['value_text'] = str_replace($search_for, $replace_with, $this->enhanced_placeholders[$placeholder]['value_text']);
			}
			if ($this->recursion_counter++ < $this->max_recursions) {
				$this->getNestedEnhancedPlaceholders($placeholder, $this->enhanced_placeholders[$placeholder], $is_construct);
			} else {
				return;
			}
		} else {
			return;
		}
	}

	protected function getPlaceholderList ($text = '') {
		$placeholders_found = array();
		preg_match_all($this->placeholder_regex, $text, $placeholders_found);
		return array_unique($placeholders_found[0]);
	}

	protected function getPlaceholderLists ($htmlmessage = '', $textmessage = '', $subject = '') {
		$this->placeholders_list_html    = $this->getPlaceholderList($htmlmessage);
		$this->placeholders_list_text    = $this->getPlaceholderList($textmessage);
		$this->placeholders_list_subject = $this->getPlaceholderList($subject);
	}

	protected function getPlaceholderValues ($placeholder, $userdata, $user_att, $is_construct = false, $is_html = false) {
		// Some placeholders may be inserted at the time of object construction.
		// Others must only be inserted at the time an email is sent. $is_construct controls this.
		if (in_array($placeholder, array_keys($this->enhanced_placeholders))) {
			$placeholder_type  = $this->enhanced_placeholders[$placeholder]['type'];
			$placeholder_value = $this->enhanced_placeholders[$placeholder]['value'];
			switch ($placeholder_type) {
				case 'html':
					if ($is_html) {
						$ret = $placeholder_value;
					} else {
						if (isset($this->enhanced_placeholders[$placeholder]['value_text'])) {
							$ret = $this->enhanced_placeholders[$placeholder]['value_text'];
						} else {
							$ret = stripHTML($placeholder_value);
						}
					}
					break;

				case 'PHP:date':
					$ret = date($placeholder_value);
					break;

				case 'PHP:eval':
					eval("\$ret = $placeholder_value;");
					break;

				case 'text':
					$ret = $placeholder_value;
					break;
			}
		} elseif (in_array($placeholder, $this->hardwired_placeholders)) {
			// There are at present four "hard-wired" placeholder. Others could be added here.
			switch ($placeholder) {
				case '{EMAIL}':
					if (!$is_construct) {
						$ret = $userdata['email'];
					}
					break;

				case '{LIST_UNSUBSCRIBEURL}':
					if (!$is_construct) {
						$ret = $this->getListUnsubscribeURL($userdata);
					}
					break;

				case '{MID}':
					if (!$is_construct) {
						$ret = $this->messageid;
					}
					break;

				case '{UID}':
					if (!$is_construct) {
						$ret = $userdata['uniqid'];
					}
					break;

				case '{VIA_LIST_NAMES}':
					if (!$is_construct) {
						$ret = $this->getViaListNames($userdata);
					}
					break;
			}
		} elseif (!$is_construct && $is_html && in_array($placeholder, array_keys($this->legacy_placeholders_html))) {
			$ret = $this->legacy_placeholders_html[$placeholder];
		} elseif (!$is_construct && !$is_html && in_array($placeholder, array_keys($this->legacy_placeholders_text))) {
			$ret = $this->legacy_placeholders_text[$placeholder];
		} elseif (!$is_construct && in_array($placeholder, array_keys($this->user_attribute_placeholders))) {
			// User attributes in form {USER ATTRIBUTE}
			$ret = $user_att[$this->user_attribute_placeholders[$placeholder]];
		} else {
			// Configuration parameters in form {CONFIGURATIONPARAMETER}
			$ret = $this->getConfigurationPlaceholderValue($placeholder);
		}
		return $ret;
	}

	protected function getUserAttributePlaceholders () {
		global $tables;
		$req = Sql_Query(sprintf('SELECT name FROM %s', $tables["attribute"]));
		while ($row = Sql_Fetch_Row($req)) {
			$this->user_attribute_placeholders['{'.strtoupper($row[0]).'}'] = $row[0];
		}
	}

	protected function getListUnsubscribeURL ($userdata) {
		if (!count($this->sent_via_listids)) {
			$this->getViaListNames($userdata);
		}
		if (1 == count($this->sent_via_listids)) {
			$unsubscribeurl	= getConfig('unsubscribeurl');
			$uid			= $userdata['uniqid'];
			$listid			= $this->sent_via_listids[0];
			return "$unsubscribeurl&uid=$uid&listid=$listid";
		} else {
			// if there is not a single list for this email, provide the general preferences URL
			return getConfig('preferencesurl').'&uid='.$userdata['uniqid'];
		}
	}

	protected function getViaListNames ($userdata) {
		global $tables;
		// This could likely be improved in such a way as to reduce the number of database queries per mailing...
		$listids = array();
		$query   = sprintf('SELECT DISTINCT listmessage.listid FROM (%s AS listuser, %s AS user, %s AS listmessage)
								LEFT JOIN %s AS usermessage ON (usermessage.messageid = %d AND usermessage.userid = listuser.userid)
							WHERE
								listmessage.messageid = %d AND
								listmessage.listid = listuser.listid AND
								user.id = listuser.userid AND
								user.id = %d',
							$tables['listuser'], $tables['user'], $tables['listmessage'], $tables['usermessage'],
								$this->messageid, $this->messageid, $userdata['id']);
		$req     = Sql_Query($query);
		while ($row = Sql_Fetch_Row($req)) {
			$listids[] = $row[0];
		}
		if (isset($listids[0])) {
			$listid = $listids[0];
		} elseif (isset($GLOBALS['listid']) && '' != $GLOBALS['listid']) {
			$listid = $GLOBALS['listid'];
		} else {
			return '';
		}
		if (!count($this->list_names) || !isset($this->list_names[$listid])) {
			$this->getListNames();
		}
		if (count($listids) < 2) {
			$this->sent_via_listids = array($listid,);
			return $this->list_names[$listid];
		} else {
			$ret = '';
			foreach ($listids as $listid) {
				if ($ret) {
					$ret .= $this->list_names_separator;
				}
				$ret .= $this->list_names[$listid];
				$this->sent_via_listids[] = $listid;
			}
		}
		return $ret;
	}

	protected function putValuesInNestedPlaceholders ($userdata, $user_att_values) {
		foreach ($this->nested_placeholders as $placeholder) {
			$placeholders_found = array();
			preg_match_all($this->placeholder_regex, $this->enhanced_placeholders[$placeholder]['value'], $placeholders_found);
			$this->putValuesInPlaceholders($placeholders_found[0], $this->enhanced_placeholders[$placeholder]['value'], $userdata, $user_att_values, false, true);
			if (isset($this->enhanced_placeholders[$placeholder]['value_text'])) {
				$placeholders_found_text = array();
				preg_match_all($this->placeholder_regex, $this->enhanced_placeholders[$placeholder]['value_text'], $placeholders_found_text);
				$this->putValuesInPlaceholders($placeholders_found_text[0], $this->enhanced_placeholders[$placeholder]['value_text'], $userdata, $user_att_values);
			}
		}
	}

	protected function putValuesInPlaceholders ($placeholders_list, &$text, $userdata, $user_att_values, $is_construct = false, $is_html = false) {
		if (count($placeholders_list)) {
			$search_for   = array();
			$replace_with = array();
			foreach ($placeholders_list as $placeholder) {
				$search_for[]   = $placeholder;
				$replace_with[] = $this->getPlaceholderValues($placeholder, $userdata, $user_att_values, $is_construct, $is_html);
			}
			$text = str_replace($search_for, $replace_with, $text);
		}
	}

	protected function retrievePlaceholderArray () {
		$tmp = unserialize(stripslashes(getConfig($this->config_table_item)));
		$this->enhanced_placeholders = is_array($tmp) ? $tmp : array();
	}

	protected function storePlaceholderArray () {
		SaveConfig($this->config_table_item, addslashes(serialize($this->enhanced_placeholders)));
	}

}
?>